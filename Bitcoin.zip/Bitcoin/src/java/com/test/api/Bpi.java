/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.api;

//import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.*;
import com.fasterxml.jackson.*;
import com.fasterxml.jackson.annotation.*;

/**
 *
 * @author utgupta
 */

@JsonPropertyOrder({
    "USD"
})
public class Bpi {

    @JsonProperty("USD")
    private USD uSD;

    @JsonProperty("USD")
    public USD getUSD() {
        return uSD;
    }

    @JsonProperty("USD")
    public void setUSD(USD uSD) {
        this.uSD = uSD;
    }

}
