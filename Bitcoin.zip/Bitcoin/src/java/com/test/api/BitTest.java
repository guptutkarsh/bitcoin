/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.api;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import org.json.simple.parser.*;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@RequestScoped
@Path("BitTest")
public class BitTest {

    @GET
    @Path("/{getData}")
    public String getPrice() {

        String output = "";
        String res = "";

        try {
            URL url = new URL("https://api.coindesk.com/v1/bpi/currentprice/USD.json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));

//            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
//                System.out.println(output);
                res += output;
            }

            ObjectMapper mapper = new ObjectMapper();
//            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            BitCoinMain bm = mapper.readValue(res, BitCoinMain.class);
            System.out.println(bm.getBpi().getUSD().getRate());

            conn.disconnect();
            PreparedStatement dimDelPS = null;
            ResultSet dimDelRS = null;
            Class.forName("com.mysql.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/bitcoin", "root", "admin") //here sonoo is database name, root is username and password
                    ) {
                String dimDelQuery = "insert into bitdata\n"
                        + "values(?,  to_char(sysdate,'YYYY-MM-DD HH:MM:SS'),to_char(sysdate,'YYYY-MM-DD HH:MM:SS'))";
                dimDelPS = con.prepareStatement(dimDelQuery);

                dimDelPS.setString(1, bm.getBpi().getUSD().getRate());
                dimDelPS.execute();
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {

        }

        return res;
    }
}
