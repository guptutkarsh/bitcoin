/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.api;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 *
 * @author utgupta
 */
public class USD {

    private String code;
    private String rate;
    private String description;
    private Double rate_float;

    public String getCode() {
        return code;
    }

    public String getRate() {
        return rate;
    }

    public String getDescription() {
        return description;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setRate_float(Double rate_Float) {
        this.rate_float = rate_Float;
    }

    public Double getRate_float() {
        return rate_float;
    }
}
