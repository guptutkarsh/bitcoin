/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.api;

import com.fasterxml.jackson.databind.*;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties

/**
 *
 * @author utgupta
 */
public class BitCoinMain {

    public Time getTime() {
        return time;
    }

    public Bpi getBpi() {
        return bpi;
    }

    public String getDisclaimer() {
        return disclaimer;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public void setBpi(Bpi bpi) {
        this.bpi = bpi;
    }

//    @JsonProperty("UsD")
    public void setDisclaimer(String disclaimer) {
        this.disclaimer = disclaimer;
    }

    private Time time;
    private Bpi bpi;
    private String disclaimer;

}
