/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.api;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties

/**
 *
 * @author utgupta
 */
class Time {

    private String updated;
    private String updatedISO;
    private String updateduk;

    public String getUpdated() {
        return updated;
    }

    public String getUpdatedISO() {
        return updatedISO;
    }

    public String getUpdateduk() {
        return updateduk;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public void setUpdatedISO(String updatedISO) {
        this.updatedISO = updatedISO;
    }

    public void setUpdateduk(String updateduk) {
        this.updateduk = updateduk;
    }
}
